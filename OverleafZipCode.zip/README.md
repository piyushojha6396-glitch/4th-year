# B.Tech Final Year Project Report — 2026
## Ajay Kumar Garg Engineering College | AKTU Lucknow

### File Structure
```
main.tex                          ← Compile this file in Overleaf
AKGEC_1_0.png                     ← College logo (already included)
References.bib                    ← Your bibliography (edit this)

frontmatter/
  Declaration.tex
  Certificate.tex
  Acknowledgements.tex
  Abstract.tex

chapters/
  Chapter1_Introduction.tex
  Chapter2_LiteratureReview.tex
  Chapter3_Methodology.tex
  Chapter4_Implementation.tex
  Chapter5_ResultsDiscussion.tex
  Chapter6_SocietalImpact.tex
  Chapter7_UHV.tex
  Chapter8_Conclusion.tex

appendices/
  AppendixA_UNAI_Certificate.tex  ← SDG Compliance Certificate
  AppendixB_Code.tex
  AppendixC_CV.tex
```

### How to Use in Overleaf
1. Upload all files maintaining the folder structure above.
2. Set **main.tex** as the main document.
3. Set **Compiler = pdfLaTeX** and **Bibliography = Biber**.
4. Edit the PROJECT DETAILS block at the top of `main.tex` first.
5. Fill in each chapter file with your content (look for TODO comments).
6. For the UNAI Certificate (AppendixA), replace `\square` with `\checkmark`
   for each applicable SDG.
7. Add your real references to `References.bib`.
